import SwiftUI

// MARK: - Chief Complaint View (Now the start of a multi-page flow)
struct ChiefComplaintView: View {
    @Environment(\.dismiss) var dismiss
    @State private var selectedComplaint: Case.ComplaintType?
    
    var body: some View {
        VStack(spacing: 0) {
                // MARK: - Top Bar
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .medium))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                            .frame(width: 44, height: 44, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    
                    Text("Chief Complaint")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                    
                    Spacer()
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.white)
                
                Divider()
                    .overlay(Color(red: 231/255, green: 235/255, blue: 243/255))
                
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Tell us about your concern")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        
                        Text("Select the primary reason for your visit today.")
                            .font(.system(size: 15, weight: .regular))
                            .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                        
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                            ComplaintCard(type: .pain, isSelected: selectedComplaint == .pain) { selectedComplaint = .pain }
                            ComplaintCard(type: .wornTeeth, isSelected: selectedComplaint == .wornTeeth) { selectedComplaint = .wornTeeth }
                            ComplaintCard(type: .poorEsthetics, isSelected: selectedComplaint == .poorEsthetics) { selectedComplaint = .poorEsthetics }
                            ComplaintCard(type: .difficultyChewing, isSelected: selectedComplaint == .difficultyChewing) { selectedComplaint = .difficultyChewing }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 20)
                }
                
                Spacer()
                
                // MARK: - Navigation Button
                NavigationLink(destination: ComplaintDetailsView()) {
                    Text("Continue")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .fill(Color(red: 0/255, green: 122/255, blue: 255/255))
                        )
                }
                .disabled(selectedComplaint == nil)
                .opacity(selectedComplaint == nil ? 0.5 : 1.0)
                .padding(16)
                .background(Color.white)
            }
            .background(Color(red: 248/255, green: 249/255, blue: 252/255))
            .navigationBarHidden(true)
    }
}

// MARK: - Complaint Card Component
private struct ComplaintCard: View {
    let type: Case.ComplaintType
    let isSelected: Bool
    let action: () -> Void
    
    var backgroundColor: LinearGradient {
        switch type {
        case .pain:
            return LinearGradient(
                colors: [Color(red: 30/255, green: 50/255, blue: 70/255), Color(red: 20/255, green: 35/255, blue: 50/255)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .wornTeeth:
            return LinearGradient(
                colors: [Color(red: 35/255, green: 45/255, blue: 60/255), Color(red: 25/255, green: 35/255, blue: 50/255)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .poorEsthetics:
            return LinearGradient(
                colors: [Color(red: 10/255, green: 10/255, blue: 10/255), Color(red: 0/255, green: 0/255, blue: 0/255)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .difficultyChewing:
            return LinearGradient(
                colors: [Color(red: 220/255, green: 180/255, blue: 180/255), Color(red: 200/255, green: 150/255, blue: 150/255)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 0) {
                ZStack {
                    backgroundColor
                    if type == .pain {
                        Image(systemName: "bolt.fill").font(.system(size: 60, weight: .bold)).foregroundColor(.white).shadow(color: .white.opacity(0.5), radius: 10)
                    } else if type == .wornTeeth {
                        Text("🦷").font(.system(size: 80))
                    } else if type == .poorEsthetics {
                        Image(systemName: "sparkles").font(.system(size: 50, weight: .bold)).foregroundColor(.yellow).shadow(color: .yellow.opacity(0.6), radius: 15)
                    } else {
                        Text("🍎").font(.system(size: 80))
                    }
                }
                .frame(height: 140)
                .frame(maxWidth: .infinity)
                
                Text(type.rawValue)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                    .padding(.vertical, 12)
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
            }
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(isSelected ? Color(red: 0/255, green: 122/255, blue: 255/255) : Color(red: 207/255, green: 215/255, blue: 231/255), lineWidth: isSelected ? 2 : 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}
