import SwiftUI

// MARK: - Case Detail View
struct CaseDetailView: View {
    @Environment(\.dismiss) var dismiss
    let caseItem: Case
    
    var statusColor: Color {
        switch caseItem.status {
        case .active:
            return Color(red: 7/255, green: 136/255, blue: 59/255)
        case .pending:
            return Color(red: 245/255, green: 158/255, blue: 11/255)
        case .completed:
            return Color(red: 59/255, green: 130/255, blue: 246/255)
        case .archived:
            return Color(red: 107/255, green: 114/255, blue: 128/255)
        }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // MARK: - Top Bar
            HStack {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .frame(width: 44, height: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                
                Spacer()
                
                Text("Case Details")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                
                Spacer()
                
                Color.clear.frame(width: 44, height: 44)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.white)
            
            Divider()
                .overlay(Color(red: 231/255, green: 235/255, blue: 243/255))
            
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    // MARK: - Patient Header
                    VStack(alignment: .leading, spacing: 16) {
                        HStack(alignment: .top, spacing: 16) {
                            // Patient Avatar
                            if let imageUrl = caseItem.patientImageUrl, let url = URL(string: imageUrl) {
                                AsyncImage(url: url) { image in
                                    image
                                        .resizable()
                                        .scaledToFill()
                                } placeholder: {
                                    Circle()
                                        .fill(Color(red: 0/255, green: 122/255, blue: 255/255).opacity(0.2))
                                        .overlay(
                                            Text(String(caseItem.patientName.prefix(1)))
                                                .font(.system(size: 28, weight: .bold))
                                                .foregroundColor(Color(red: 0/255, green: 122/255, blue: 255/255))
                                        )
                                }
                                .frame(width: 72, height: 72)
                                .clipShape(Circle())
                            } else {
                                Circle()
                                    .fill(Color(red: 0/255, green: 122/255, blue: 255/255).opacity(0.2))
                                    .frame(width: 72, height: 72)
                                    .overlay(
                                        Text(String(caseItem.patientName.prefix(1)))
                                            .font(.system(size: 28, weight: .bold))
                                            .foregroundColor(Color(red: 0/255, green: 122/255, blue: 255/255))
                                    )
                            }
                            
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Text(caseItem.patientName)
                                        .font(.system(size: 24, weight: .bold))
                                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                                    
                                    Spacer()
                                    
                                    Text(caseItem.status.rawValue)
                                        .font(.system(size: 13, weight: .semibold))
                                        .foregroundColor(statusColor)
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 6)
                                        .background(
                                            Capsule()
                                                .fill(statusColor.opacity(0.15))
                                        )
                                }
                                
                                HStack(spacing: 16) {
                                    HStack(spacing: 6) {
                                        Image(systemName: "person.circle")
                                            .font(.system(size: 14))
                                            .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                                        
                                        Text("ID: \(caseItem.patientId)")
                                            .font(.system(size: 14))
                                            .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                                    }
                                    
                                    HStack(spacing: 6) {
                                        Image(systemName: "calendar")
                                            .font(.system(size: 14))
                                            .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                                        
                                        Text(formatDate(caseItem.createdDate))
                                            .font(.system(size: 14))
                                            .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                                    }
                                }
                            }
                        }
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(red: 207/255, green: 215/255, blue: 231/255), lineWidth: 1)
                    )
                    
                    // MARK: - Chief Complaint
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .font(.system(size: 16))
                                .foregroundColor(Color(red: 0/255, green: 122/255, blue: 255/255))
                            
                            Text("Chief Complaint")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        }
                        
                        Text(caseItem.complaintType.rawValue)
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(red: 242/255, green: 244/255, blue: 248/255))
                            .cornerRadius(8)
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(red: 207/255, green: 215/255, blue: 231/255), lineWidth: 1)
                    )
                    
                    // MARK: - Additional Details
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "doc.text.fill")
                                .font(.system(size: 16))
                                .foregroundColor(Color(red: 0/255, green: 122/255, blue: 255/255))
                            
                            Text("Additional Details")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        }
                        
                        Text(caseItem.additionalDetails)
                            .font(.system(size: 15))
                            .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                            .lineSpacing(4)
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(red: 207/255, green: 215/255, blue: 231/255), lineWidth: 1)
                    )
                    
                    // MARK: - Medical History
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "heart.text.square.fill")
                                .font(.system(size: 16))
                                .foregroundColor(Color(red: 0/255, green: 122/255, blue: 255/255))
                            
                            Text("Medical History")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        }
                        
                        Text(caseItem.medicalHistory)
                            .font(.system(size: 15))
                            .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                            .lineSpacing(4)
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(red: 207/255, green: 215/255, blue: 231/255), lineWidth: 1)
                    )
                    
                    // MARK: - Doctor Information
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "stethoscope")
                                .font(.system(size: 16))
                                .foregroundColor(Color(red: 0/255, green: 122/255, blue: 255/255))
                            
                            Text("Assigned Doctor")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        }
                        
                        HStack(spacing: 12) {
                            Circle()
                                .fill(Color(red: 0/255, green: 122/255, blue: 255/255).opacity(0.2))
                                .frame(width: 48, height: 48)
                                .overlay(
                                    Text(String(caseItem.doctorName.prefix(1)))
                                        .font(.system(size: 18, weight: .bold))
                                        .foregroundColor(Color(red: 0/255, green: 122/255, blue: 255/255))
                                )
                            
                            VStack(alignment: .leading, spacing: 2) {
                                Text(caseItem.doctorName)
                                    .font(.system(size: 15, weight: .medium))
                                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                                
                                Text("Dental Specialist")
                                    .font(.system(size: 13))
                                    .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                            }
                            
                            Spacer()
                        }
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(red: 207/255, green: 215/255, blue: 231/255), lineWidth: 1)
                    )
                }
                .padding(16)
                .padding(.bottom, 24)
            }
            
            // MARK: - Action Buttons
            VStack(spacing: 12) {
                Divider()
                    .overlay(Color(red: 231/255, green: 235/255, blue: 243/255))
                
                HStack(spacing: 12) {
                    NavigationLink(destination: PatientInfoView()) {
                        HStack(spacing: 6) {
                            Image(systemName: "pencil")
                                .font(.system(size: 16, weight: .medium))
                            Text("Edit")
                                .font(.system(size: 16, weight: .semibold))
                        }
                        .foregroundColor(Color(red: 0/255, green: 122/255, blue: 255/255))
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .stroke(Color(red: 0/255, green: 122/255, blue: 255/255), lineWidth: 1.5)
                        )
                    }
                    .buttonStyle(.plain)
                    
                    NavigationLink(destination: UpdateStatusView(caseItem: caseItem)) {
                        Text("Update Status")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(Color(red: 0/255, green: 122/255, blue: 255/255))
                            )
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 16)
            }
            .background(Color.white)
        }
        .background(Color(red: 248/255, green: 249/255, blue: 252/255))
        .navigationBarHidden(true)
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, yyyy"
        return formatter.string(from: date)
    }
}

#Preview {
    NavigationStack {
        CaseDetailView(caseItem: Case.sampleCases[0])
    }
}
