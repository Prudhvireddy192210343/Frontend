import SwiftUI

// MARK: - Insights View (matches your HTML UI)
struct InsightsView: View {

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {

                    // MARK: - Top Bar
                    HStack {
                        Button {
                            dismiss()
                        } label: {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 20, weight: .regular))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255)) // #0d121b
                                .frame(width: 44, height: 44)
                                .contentShape(Rectangle())
                        }

                        Text("Insights")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                            .frame(maxWidth: .infinity, alignment: .center)

                        // Spacer to mimic "pr-12"
                        Color.clear
                            .frame(width: 44, height: 44)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 10)
                    .padding(.bottom, 8)
                    .background(Color(red: 248/255, green: 249/255, blue: 252/255)) // #f8f9fc

                    // MARK: - Monthly Practice Overview Card
                    HStack(alignment: .top, spacing: 14) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Monthly Practice Overview")
                                .font(.system(size: 14))
                                .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255)) // #4c669a

                            Text("Cases Processed")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255)) // #0d121b

                            Text("24")
                                .font(.system(size: 14))
                                .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)

                        AsyncImage(url: URL(string: "https://lh3.googleusercontent.com/aida-public/AB6AXuAShN9cxSSadiqvyMczMsn9mvPmxESEmWJ4jilnXduGJEMjFRdBwGiXgj0h6WW7KujgDmwKu9LZdJHRHvjkXAk4K5fnuXzcuxv0XoCJ8P2vDsjdWWJDwf9VY7g9hhiaxQT01irLCB077NkAq5OtjFFUluwUN9bDuOhXhpEeZ9Q8abNGniY00xrlA-IsPSpbHsjgrdus5x0LnwE2l2yeSoixWUd6Pu1g-m7FCxbwB-awV-W2IjPCE3DmsvNnbSNdiniMUgc5StEsmR4")) { img in
                            img.resizable().scaledToFill()
                        } placeholder: {
                            Color.gray.opacity(0.15)
                        }
                        .frame(width: 160, height: 90)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                    .padding(16)

                    // MARK: - Stat Cards
                    HStack(spacing: 12) {
                        InsightStatCard(title: "Avg. Treatment Success", value: "98%")
                        InsightStatCard(title: "Clinical Efficiency", value: "+15%")
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 6)

                    // MARK: - Case Success Rates
                    Text("Case Success Rates")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .padding(.horizontal, 16)
                        .padding(.top, 18)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Case Success Rates")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))

                        HStack(alignment: .bottom, spacing: 18) {
                            BarItem(heightPercent: 0.60, label: "Full Rehabilitation")
                            BarItem(heightPercent: 0.60, label: "Orthodontics")
                            BarItem(heightPercent: 0.70, label: "Implants")
                        }
                        .frame(minHeight: 180)
                        .padding(.horizontal, 6)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)

                    // MARK: - Top Findings
                    Text("Top Findings")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .padding(.horizontal, 16)
                        .padding(.top, 6)
                        .padding(.bottom, 10)

                    InsightRow(icon: "flag", title: "Bruxism detected", subtitle: "40% of cases")

                    // MARK: - Predictive Trends
                    Text("Predictive Trends")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .padding(.horizontal, 16)
                        .padding(.top, 18)
                        .padding(.bottom, 6)

                    Text("AI-generated forecast of upcoming high-complexity cases.")
                        .font(.system(size: 16))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .padding(.horizontal, 16)
                        .padding(.bottom, 14)
                }
            }

        }
        .background(Color(red: 248/255, green: 249/255, blue: 252/255)) // #f8f9fc
        .navigationBarHidden(true)
    }
}

// MARK: - Small Components

private struct InsightStatCard: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))

            Text(value)
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
        }
        .padding(16)
        .frame(maxWidth: .infinity, minHeight: 92, alignment: .leading)
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(Color(red: 207/255, green: 215/255, blue: 231/255), lineWidth: 1) // #cfd7e7
        )
    }
}

private struct BarItem: View {
    let heightPercent: CGFloat   // 0.0 - 1.0
    let label: String

    var body: some View {
        VStack(spacing: 8) {
            RoundedRectangle(cornerRadius: 0)
                .fill(Color(red: 231/255, green: 235/255, blue: 243/255)) // #e7ebf3
                .overlay(
                    Rectangle()
                        .fill(Color.clear)
                        .frame(height: 2)
                        .background(Color(red: 76/255, green: 102/255, blue: 154/255)), // border-top look
                    alignment: .top
                )
                .frame(width: 70)
                .frame(height: 180 * heightPercent)

            Text(label)
                .font(.system(size: 13, weight: .bold))
                .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255)) // #4c669a
                .multilineTextAlignment(.center)
                .frame(width: 80)
        }
        .frame(maxHeight: .infinity, alignment: .bottom)
    }
}

private struct InsightRow: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color(red: 231/255, green: 235/255, blue: 243/255)) // #e7ebf3
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .regular))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                Text(subtitle)
                    .font(.system(size: 14))
                    .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
            }

            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }
}


#Preview {
    NavigationStack {
        InsightsView()
    }
}
