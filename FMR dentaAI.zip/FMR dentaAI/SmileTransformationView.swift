import SwiftUI

struct SmileTransformationView: View {
    @Environment(\.dismiss) var dismiss
    @State private var selectedToggle = "Final"
    
    var body: some View {
        VStack(spacing: 0) {
            // MARK: - Top Bar
            HStack {
                Button {
                    dismiss()
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .medium))
                        Text("Back")
                            .font(.system(size: 16, weight: .medium))
                    }
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                    .frame(height: 44)
                }
                .buttonStyle(.plain)
                
                Spacer()
                
                Text("Smile Transformation")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                
                Spacer()
                
                Color.clear.frame(width: 44, height: 44)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.white)
            
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    // Before Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Before")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        
                        AsyncImage(url: URL(string: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=800&auto=format&fit=crop")) { image in
                            image.resizable().scaledToFill()
                        } placeholder: {
                            Color.gray.opacity(0.1)
                                .overlay(ProgressView())
                        }
                        .frame(height: 220)
                        .frame(maxWidth: .infinity)
                        .cornerRadius(12)
                        .clipped()
                    }
                    
                    // After Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("After")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        
                        AsyncImage(url: URL(string: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?q=80&w=800&auto=format&fit=crop")) { image in
                            image.resizable().scaledToFill()
                        } placeholder: {
                            Color.gray.opacity(0.1)
                                .overlay(ProgressView())
                        }
                        .frame(height: 220)
                        .frame(maxWidth: .infinity)
                        .cornerRadius(12)
                        .clipped()
                    }
                    
                    // Toggle
                    HStack(spacing: 0) {
                        Button {
                            selectedToggle = "Provisional"
                        } label: {
                            Text("Provisional")
                                .font(.system(size: 14, weight: .medium))
                                .frame(maxWidth: .infinity)
                                .frame(height: 44)
                                .background(selectedToggle == "Provisional" ? Color.white : Color.clear)
                                .foregroundColor(selectedToggle == "Provisional" ? Color(red: 13/255, green: 18/255, blue: 27/255) : Color(red: 76/255, green: 102/255, blue: 154/255))
                                .cornerRadius(8)
                                .padding(4)
                        }
                        .buttonStyle(.plain)
                        
                        Button {
                            selectedToggle = "Final"
                        } label: {
                            Text("Final")
                                .font(.system(size: 14, weight: .medium))
                                .frame(maxWidth: .infinity)
                                .frame(height: 44)
                                .background(selectedToggle == "Final" ? Color.white : Color.clear)
                                .foregroundColor(selectedToggle == "Final" ? Color(red: 13/255, green: 18/255, blue: 27/255) : Color(red: 76/255, green: 102/255, blue: 154/255))
                                .cornerRadius(8)
                                .padding(4)
                        }
                        .buttonStyle(.plain)
                    }
                    .background(Color(red: 231/255, green: 235/255, blue: 243/255))
                    .cornerRadius(12)
                    .padding(.top, 20)
                }
                .padding(16)
            }
            
            // MARK: - Bottom Tab Bar

        }
        .background(Color(red: 248/255, green: 249/255, blue: 252/255))
        .navigationBarHidden(true)
    }
}

#Preview {
    SmileTransformationView()
}
