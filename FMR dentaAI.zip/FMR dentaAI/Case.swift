import Foundation

// MARK: - Case Model
struct Case: Identifiable, Codable {
    let id: String
    var patientName: String
    var patientId: String
    var patientImageUrl: String?
    var chiefComplaint: String
    var complaintType: ComplaintType
    var additionalDetails: String
    var medicalHistory: String
    var status: CaseStatus
    var createdDate: Date
    var lastUpdated: Date
    var doctorId: String
    var doctorName: String
    
    enum ComplaintType: String, Codable, CaseIterable {
        case pain = "Pain"
        case wornTeeth = "Worn Teeth"
        case poorEsthetics = "Poor Esthetics"
        case difficultyChewing = "Difficulty Chewing"
        
        var icon: String {
            switch self {
            case .pain: return "Pain"
            case .wornTeeth: return "Worn Teeth"
            case .poorEsthetics: return "Poor Esthetics"
            case .difficultyChewing: return "Difficulty Chewing"
            }
        }
    }
    
    enum CaseStatus: String, Codable {
        case active = "Active"
        case pending = "Pending Approval"
        case completed = "Completed"
        case archived = "Archived"
        
        var color: String {
            switch self {
            case .active: return "#07883b" // green
            case .pending: return "#f59e0b" // amber
            case .completed: return "#3b82f6" // blue
            case .archived: return "#6b7280" // gray
            }
        }
    }
}

// MARK: - Sample Data
extension Case {
    static let sampleCases: [Case] = [
        Case(
            id: "2024001",
            patientName: "Mahi",
            patientId: "2024001",
            patientImageUrl: "https://i.pravatar.cc/150?img=47",
            chiefComplaint: "Chief Complaint: Toothache",
            complaintType: .pain,
            additionalDetails: "Sharp pain in lower right molar, sensitivity to cold",
            medicalHistory: "No known allergies",
            status: .active,
            createdDate: Date().addingTimeInterval(-86400 * 5),
            lastUpdated: Date().addingTimeInterval(-3600),
            doctorId: "DR001",
            doctorName: "Dr. Tanu"
        ),
        Case(
            id: "2024002",
            patientName: "Prudhvi",
            patientId: "2024002",
            patientImageUrl: "https://i.pravatar.cc/150?img=33",
            chiefComplaint: "Chief Complaint: Missing tooth",
            complaintType: .poorEsthetics,
            additionalDetails: "Missing upper front tooth after accident",
            medicalHistory: "Diabetic",
            status: .active,
            createdDate: Date().addingTimeInterval(-86400 * 3),
            lastUpdated: Date().addingTimeInterval(-7200),
            doctorId: "DR001",
            doctorName: "Dr. Tanu"
        ),
        Case(
            id: "2024003",
            patientName: "Raju",
            patientId: "2024003",
            patientImageUrl: "https://i.pravatar.cc/150?img=51",
            chiefComplaint: "Chief Complaint: Discomfort",
            complaintType: .difficultyChewing,
            additionalDetails: "Difficulty chewing on left side",
            medicalHistory: "None",
            status: .pending,
            createdDate: Date().addingTimeInterval(-86400 * 2),
            lastUpdated: Date().addingTimeInterval(-1800),
            doctorId: "DR001",
            doctorName: "Dr. Tanu"
        )
    ]
}

// MARK: - Case Repository
class CaseRepository: ObservableObject {
    static let shared = CaseRepository()
    
    @Published var cases: [Case] = Case.sampleCases
    
    // Draft case for new submission flow
    @Published var draftPatientName: String = ""
    @Published var draftPatientAge: String = ""
    @Published var draftPatientGender: String = "Male"
    @Published var draftChiefComplaint: String = ""
    @Published var draftAdditionalDetails: String = ""
    
    private init() {}
    
    func addCase(fromDraft: Bool = true) {
        let newCase = Case(
            id: String(Int.random(in: 1000...9999)),
            patientName: draftPatientName.isEmpty ? "New Patient" : draftPatientName,
            patientId: String(Int.random(in: 2024004...2025000)),
            patientImageUrl: nil,
            chiefComplaint: draftChiefComplaint.isEmpty ? "Chief Complaint: Evaluation" : "Chief Complaint: \(draftChiefComplaint)",
            complaintType: .poorEsthetics, // Default or derived
            additionalDetails: draftAdditionalDetails,
            medicalHistory: "Age: \(draftPatientAge), Gender: \(draftPatientGender)",
            status: .active,
            createdDate: Date(),
            lastUpdated: Date(),
            doctorId: "DR001",
            doctorName: "Dr. LoggedIn"
        )
        
        cases.insert(newCase, at: 0)
        
        // Reset draft
        draftPatientName = ""
        draftPatientAge = ""
        draftPatientGender = "Male"
        draftChiefComplaint = ""
        draftAdditionalDetails = ""
    }
}
