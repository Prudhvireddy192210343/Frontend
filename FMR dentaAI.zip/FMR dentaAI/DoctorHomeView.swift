import SwiftUI

// MARK: - Doctor Home / Dashboard
struct DoctorHomeView: View {
    @State private var showNotifications = false

    var body: some View {
        VStack(spacing: 0) {

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {

                    // MARK: - Top Bar
                    HStack {

                        // Avatar → DoctorProfileView
                        NavigationLink(destination: DoctorProfileView()) {
                            AsyncImage(url: URL(string: "https://lh3.googleusercontent.com/aida-public/AB6AXuBbkAAQjR7W94fU8WRtGzOiOtstRqX7sCY2-CQsAhRtBb2-crhl_8wt8deMRf4k_bNaURu-KjhCgQYHomzS38iAmDV72Y_RxDD6RxfZvO1rRVs1CrrFzOwqAesJ6ZsGqog3aE9rf7fWANDiUqAssOFnF7IqwpZ90kljMQDvi0Rqzoqdvwkyvhib-5O_bc3e6W7FQy0DWMGICDLvACIuGnGk7wYg28KAxMYvVZ2-mQGja_DZgOqLcnH6vMwihRs7syVHYRfc1QvfS00")) { image in
                                image.resizable().scaledToFill()
                            } placeholder: {
                                Color.gray.opacity(0.2)
                            }
                            .frame(width: 32, height: 32)
                            .clipShape(Circle())
                        }
                        .buttonStyle(.plain)

                        Spacer()

                        Button {
                            showNotifications = true
                        } label: {
                            Image(systemName: "bell")
                                .font(.system(size: 22, weight: .regular))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255)) // #0d121b
                                .frame(width: 44, height: 44)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .background(
                            NavigationLink(destination: NotificationsView(), isActive: $showNotifications) {
                                EmptyView()
                            }
                            .hidden()
                        )
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 16)
                    .padding(.bottom, 6)

                    // MARK: - Title
                    Text("Welcome back, Dr. Tanu")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255)) // #0d121b
                        .padding(.horizontal, 16)
                        .padding(.top, 10)
                        .padding(.bottom, 10)

                    // MARK: - Start New Patient Case Card
                    NavigationLink(destination: ChiefComplaintView()) {
                        HStack(alignment: .top, spacing: 14) {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Start New Patient Case")
                                    .font(.system(size: 14, weight: .regular))
                                    .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255)) // #4c669a

                                Text("Add a new patient case")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))

                                Text("Begin a new treatment plan")
                                    .font(.system(size: 14, weight: .regular))
                                    .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)

                            AsyncImage(url: URL(string: "https://lh3.googleusercontent.com/aida-public/AB6AXuDV-sWTIx0OOM2-BUuWhd28HO6hJSFSjWmEFCatdeD-S_vhO4_-4ER2RTqYi57zpsfHnwB4ceognPpS9o8_sVNb_RpF0tPFqVNTvb_SI1hDFGBEbytSzWEkOW4PfKfqWeU6YKOJ3iu5WYmCxf_73bttB-5XluNRqDjpbJciq8gf4MfiA7R3wu3gYTOZ2H2pKnssS2OEM25rQtZUUME7UdiYy2WAroCkPZyxXmyMRQu7ikHExWKIzN-JJ2q12tOiKh5hmXI08IxdMls")) { image in
                                image.resizable().scaledToFill()
                            } placeholder: {
                                Color.gray.opacity(0.15)
                            }
                            .frame(width: 160, height: 90)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }
                        .padding(16)
                        .background(Color.clear)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                    .buttonStyle(.plain)


                    // MARK: - Case Statistics
                    Text("Case Statistics")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .padding(.horizontal, 16)
                        .padding(.top, 12)
                        .padding(.bottom, 8)

                    VStack(spacing: 12) {
                        HStack(spacing: 12) {
                            StatCard(title: "Active Plans", value: "12")
                            StatCard(title: "Pending Approval", value: "5")
                        }
                        HStack(spacing: 12) {
                            StatCard(title: "Completed", value: "48")
                            Spacer(minLength: 0)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 10)

                    // MARK: - Recent Patient Cases
                    Text("Recent Patient Cases")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .padding(.horizontal, 16)
                        .padding(.top, 10)
                        .padding(.bottom, 8)

                    ForEach(Case.sampleCases) { caseItem in
                        NavigationLink(destination: CaseDetailView(caseItem: caseItem)) {
                            RecentCaseRow(name: caseItem.patientName,
                                          complaint: caseItem.chiefComplaint,
                                          idText: "ID: \(caseItem.patientId)",
                                          isActive: caseItem.status == .active)
                        }
                        .buttonStyle(.plain)
                    }

                    Spacer(minLength: 12)
                }
                .padding(.bottom, 10)
            }

        }
        .background(Color(red: 248/255, green: 249/255, blue: 252/255)) // #f8f9fc
        .navigationBarHidden(true)
    }
}

// MARK: - Components

private struct StatCard: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))

            Text(value)
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
        }
        .padding(16)
        .frame(maxWidth: .infinity, minHeight: 88, alignment: .leading)
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(Color(red: 207/255, green: 215/255, blue: 231/255), lineWidth: 1) // #cfd7e7
        )
        .background(Color.clear)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

private struct RecentCaseRow: View {
    let name: String
    let complaint: String
    let idText: String
    let isActive: Bool

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(name)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))

                Text(complaint)
                    .font(.system(size: 14))
                    .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255)) // #4c669a

                Text(idText)
                    .font(.system(size: 14))
                    .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
            }

            Spacer()

            Circle()
                .fill(isActive ? Color(red: 7/255, green: 136/255, blue: 59/255) : Color.gray.opacity(0.4)) // #07883b
                .frame(width: 10, height: 10)
                .padding(.trailing, 6)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.clear)
    }
}


#Preview {
    NavigationStack {
        DoctorHomeView()
    }
}
