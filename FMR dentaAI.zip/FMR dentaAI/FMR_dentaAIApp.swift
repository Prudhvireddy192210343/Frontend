import SwiftUI

@main
struct FMR_dentaAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
