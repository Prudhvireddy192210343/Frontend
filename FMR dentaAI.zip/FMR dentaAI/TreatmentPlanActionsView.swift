import SwiftUI

struct TreatmentPlanActionsView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // MARK: - Top Bar
            HStack {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .frame(width: 44, height: 44, alignment: .leading)
                }
                .buttonStyle(.plain)
                
                Spacer()
                
                Text("Treatment Plan Actions")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                
                Spacer()
                
                Color.clear.frame(width: 44, height: 44)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.white)
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 32) {
                    // Module 1: Smile Transformation
                    ActionCard(
                        title: "Smile Transformation",
                        buttonText: "Upload",
                        imageURL: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=800&auto=format&fit=crop",
                        destination: AnyView(SmileTransformationView())
                    )
                    
                    // Module 2: Final Review
                    ActionCard(
                        title: "Final Review",
                        buttonText: "Review",
                        imageURL: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?q=80&w=800&auto=format&fit=crop",
                        destination: AnyView(FinalReviewView())
                    )
                    
                    // Module 3: Summary
                    ActionCard(
                        title: "Summary",
                        buttonText: "View",
                        imageURL: "https://images.unsplash.com/photo-1629909613654-28a3a7c4ad45?q=80&w=800&auto=format&fit=crop",
                        destination: AnyView(CaseSummaryReportView())
                    )
                    
                    // Module 4: Download Summary
                    ActionCard(
                        title: "Case Summary",
                        buttonText: "Download",
                        imageURL: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?q=80&w=800&auto=format&fit=crop",
                        destination: AnyView(CaseSummaryReportView())
                    )
                }
                .padding(20)
            }
        }
        .background(Color(red: 248/255, green: 249/255, blue: 252/255))
        .navigationBarHidden(true)
    }
}

private struct ActionCard: View {
    let title: String
    let buttonText: String
    let imageURL: String
    let destination: AnyView
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Hero area for card
            AsyncImage(url: URL(string: imageURL)) { image in
                image.resizable().scaledToFill()
            } placeholder: {
                Color.gray.opacity(0.1)
                    .overlay(ProgressView())
            }
            .frame(maxWidth: .infinity)
            .frame(height: 180)
            .cornerRadius(12)
            .clipped()
            
            HStack {
                Text(title)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                
                Spacer()
                
                NavigationLink(destination: destination) {
                    Text(buttonText)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 10)
                        .background(RoundedRectangle(cornerRadius: 8).fill(Color(red: 37/255, green: 99/255, blue: 235/255)))
                }
                .buttonStyle(.plain)
            }
        }
    }
}

#Preview {
    TreatmentPlanActionsView()
}
