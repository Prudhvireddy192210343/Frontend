import SwiftUI

struct DoctorProfileView: View {

    @Environment(\.dismiss) private var dismiss

    @State private var fullName = ""
    @State private var selectedSpecialty = "Select specialty"
    @State private var yearsOfExperience = ""
    @State private var clinicName = ""
    @State private var showPhotoPicker = false

    private let specialties = [
        "Select specialty",
        "Prosthodontist",
        "Orthodontist",
        "Periodontist",
        "Endodontist",
        "Oral Surgeon",
        "General Dentist"
    ]

    var body: some View {
        VStack(spacing: 0) {

            // MARK: - Top Bar
            HStack {
                Button { dismiss() } label: {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 20, weight: .regular))
                        .foregroundColor(Color(red: 17/255, green: 20/255, blue: 24/255)) // #111418
                        .frame(width: 44, height: 44)
                        .contentShape(Rectangle())
                }

                Text("Doctor Profile")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(red: 17/255, green: 20/255, blue: 24/255))
                    .frame(maxWidth: .infinity)

                // Right spacing like "pr-12"
                Color.clear
                    .frame(width: 44, height: 44)
            }
            .padding(.horizontal, 16)
            .padding(.top, 10)
            .padding(.bottom, 6)
            .background(Color.white)

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {

                    // MARK: - Avatar + Text
                    VStack(spacing: 14) {
                        Button {
                            // Action to change photo
                            showPhotoPicker = true
                        } label: {
                            ZStack(alignment: .bottomTrailing) {
                                AsyncImage(url: URL(string: "https://lh3.googleusercontent.com/aida-public/AB6AXuAIBCLjd2d9Qz3kGT0Y0XMWR5jheo3V3IVd9ZMO3GU0xp9QPDdtOXZB3b24lsDYOX0qOVnBrF96PHGkxopMvPoXfh9ZT9KKjhFHr8iUHf2kMd_aU7mLnLRlxeNMRq2goWUzdA3a5BPpf9uFSYG5LW8JN3FnNT_WvyZ40C7yDncRheXAAp6gZArDihfZG5r7sTADi9k_vTaTnuwF9vUl3vI2SJT60Q2aUvq5vpjbw8IJXG_qQdzlWMejiLyU-0Yl_ICnJ-eX4MBFaIQ")) { image in
                                    image.resizable().scaledToFill()
                                } placeholder: {
                                    Color.gray.opacity(0.15)
                                }
                                .frame(width: 128, height: 128)
                                .clipShape(Circle())
                                
                                Image(systemName: "camera.fill")
                                    .foregroundColor(.white)
                                    .padding(8)
                                    .background(Color.blue)
                                    .clipShape(Circle())
                                    .offset(x: -4, y: -4)
                            }
                        }
                        .buttonStyle(.plain)
                        .alert("Change Profile Photo", isPresented: $showPhotoPicker) {
                            Button("Choose from Library") { }
                            Button("Take Photo") { }
                            Button("Cancel", role: .cancel) { }
                        }

                        VStack(spacing: 6) {
                            Text("Set up your clinical profile")
                                .font(.system(size: 22, weight: .bold))
                                .foregroundColor(Color(red: 17/255, green: 20/255, blue: 24/255))
                                .multilineTextAlignment(.center)

                            Text("Complete your details for personalized AI-assisted planning")
                                .font(.system(size: 16, weight: .regular))
                                .foregroundColor(Color(red: 97/255, green: 117/255, blue: 137/255)) // #617589
                                .multilineTextAlignment(.center)
                        }
                        .padding(.horizontal, 16)
                    }
                    .padding(.top, 10)
                    .padding(.bottom, 8)

                    // MARK: - Fields
                    fieldText(title: "Full Name", placeholder: "Dr. Amelia Hayes", text: $fullName)

                    specialtyPicker()

                    fieldText(title: "Years of Experience", placeholder: "e.g. 10", text: $yearsOfExperience, keyboard: .numberPad)

                    fieldText(title: "Clinic Name", placeholder: "Bright Smile Clinic", text: $clinicName)

                    // MARK: - AI Assist Card + Button
                    VStack(alignment: .leading, spacing: 14) {
                        HStack(alignment: .top, spacing: 16) {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("AI assists, clinician decides")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(Color(red: 17/255, green: 20/255, blue: 24/255))

                                Text("Our AI tools provide insights and suggestions, but the final treatment plan is always in your hands.")
                                    .font(.system(size: 16, weight: .regular))
                                    .foregroundColor(Color(red: 97/255, green: 117/255, blue: 137/255))
                            }
                            
                            Spacer()
                        }
                    }
                    .padding(16)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(red: 219/255, green: 224/255, blue: 230/255), lineWidth: 1) // #dbe0e6
                    )
                    .background(Color.white)
                    .cornerRadius(12)
                    .padding(.horizontal, 16)
                    .padding(.top, 14)
                    .padding(.bottom, 18)
                }
            }
            .background(Color.white)
        }
        .background(Color.white)
        .navigationBarHidden(true)
    }

    // MARK: - Reusable Field
    private func fieldText(title: String,
                           placeholder: String,
                           text: Binding<String>,
                           keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(Color(red: 17/255, green: 20/255, blue: 24/255))

            TextField(placeholder, text: text)
                .keyboardType(keyboard)
                .textInputAutocapitalization(.words)
                .autocorrectionDisabled(true)
                .padding(.horizontal, 15)
                .frame(height: 56)
                .background(Color.white)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color(red: 219/255, green: 224/255, blue: 230/255), lineWidth: 1) // #dbe0e6
                )
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }

    // MARK: - Specialty Picker (looks like dropdown)
    private func specialtyPicker() -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Specialty")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(Color(red: 17/255, green: 20/255, blue: 24/255))

            Menu {
                ForEach(specialties, id: \.self) { item in
                    Button(item) { selectedSpecialty = item }
                }
            } label: {
                HStack {
                    Text(selectedSpecialty)
                        .foregroundColor(selectedSpecialty == "Select specialty"
                                         ? Color(red: 97/255, green: 117/255, blue: 137/255)
                                         : Color(red: 17/255, green: 20/255, blue: 24/255))
                        .font(.system(size: 16, weight: .regular))

                    Spacer()

                    Image(systemName: "chevron.down")
                        .foregroundColor(Color(red: 97/255, green: 117/255, blue: 137/255))
                        .font(.system(size: 14, weight: .semibold))
                }
                .padding(.horizontal, 15)
                .frame(height: 56)
                .background(Color.white)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color(red: 219/255, green: 224/255, blue: 230/255), lineWidth: 1) // #dbe0e6
                )
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }
}

#Preview {
    NavigationStack {
        DoctorProfileView()
    }
}


