import SwiftUI

// MARK: - Settings Screen
struct SettingsView: View {

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {

                    // MARK: - Top Bar
                    HStack {
                        Button { dismiss() } label: {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 20, weight: .regular))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255)) // #0d121b
                                .frame(width: 44, height: 44)
                                .contentShape(Rectangle())
                        }

                        Text("Settings")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                            .frame(maxWidth: .infinity)

                        // spacing like "pr-12"
                        Color.clear
                            .frame(width: 44, height: 44)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 10)
                    .padding(.bottom, 8)
                    .background(Color(red: 248/255, green: 249/255, blue: 252/255)) // #f8f9fc

                    // MARK: - Profile Header + Edit Button
                    HStack(alignment: .center, spacing: 14) {

                        AsyncImage(url: URL(string: "https://lh3.googleusercontent.com/aida-public/AB6AXuBnZ9JnHakGor2-lvinTaz3-MjBMaVn77BXOT1TqKd2Cv4Ojc5zA2SvtJPC3IP_FC0I6Nu9KQrR6u0WqbTGaQGVPlD19xO9xRv-dlJJvfoRY-GVfb5yKyuCdZ8Sb9FExms63bZMKtEPf_iouQSJ7fJtN8kJ8vBJ-jx7fFWRwRphE7jcJbVanCjI8le66kmKcFWvaLvMorPzlrs74yWJDEFFYUAeQSkvA-v2NYrZtIDS61swGd9XdIRnAk8mCgmoenwmjmTrXWxuUOQ")) { image in
                            image.resizable().scaledToFill()
                        } placeholder: {
                            Color.gray.opacity(0.15)
                        }
                        .frame(width: 128, height: 128)
                        .clipShape(Circle())

                        VStack(alignment: .leading, spacing: 6) {
                            Text("Dr. Tanu")
                                .font(.system(size: 22, weight: .bold))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                            Text("Prosthodontist")
                                .font(.system(size: 16, weight: .regular))
                                .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255)) // #4c669a
                        }

                        Spacer()

                        Button {
                            // Edit profile action
                        } label: {
                            Text("Edit Profile")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                                .padding(.horizontal, 14)
                                .frame(height: 40)
                                .background(Color(red: 231/255, green: 235/255, blue: 243/255)) // #e7ebf3
                                .cornerRadius(10)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 10)
                    .padding(.bottom, 12)

                    // MARK: - Account Settings
                    sectionTitle("Account Settings")

                    // Email Row (with subtitle)
                    RowWithSubtitle(
                        icon: "envelope",
                        title: "Email",
                        subtitle: "dr.tanu@dentaplan.ai"
                    )

                    SimpleRow(icon: "lock", title: "Password")
                    SimpleRow(icon: "shield", title: "Security")

                    // MARK: - Practice Management
                    sectionTitle("Practice Management")
                    SimpleRow(icon: "building.2", title: "Clinic Details")
                    SimpleRow(icon: "person.2", title: "Staff Access")

                    // MARK: - App Preferences
                    sectionTitle("App Preferences")
                    SimpleRow(icon: "sun.max", title: "Theme")
                    SimpleRow(icon: "bell", title: "Notifications")
                    SimpleRow(icon: "globe", title: "Language")

                    // MARK: - AI Configuration
                    sectionTitle("AI Configuration")
                    SimpleRow(icon: "slider.horizontal.3", title: "Clinical Sensitivity")
                    SimpleRow(icon: "cpu", title: "Algorithm Updates")

                    // MARK: - Legal & Compliance
                    sectionTitle("Legal & Compliance")
                    SimpleRow(icon: "doc.text", title: "Privacy Policy")
                    SimpleRow(icon: "doc.text", title: "HIPAA Information")

                    Spacer(minLength: 14)
                }
            }

            // MARK: - Log Out Button
            Button {
                // logout action
            } label: {
                Text("Log Out")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                    .frame(maxWidth: .infinity)
                    .frame(height: 40)
                    .background(Color(red: 231/255, green: 235/255, blue: 243/255)) // #e7ebf3
                    .cornerRadius(10)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 16)
            .padding(.top, 10)

        }
        .background(Color(red: 248/255, green: 249/255, blue: 252/255)) // #f8f9fc
        .navigationBarHidden(true)
    }

    // MARK: - Helpers
    private func sectionTitle(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 18, weight: .bold))
            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
            .padding(.horizontal, 16)
            .padding(.top, 14)
            .padding(.bottom, 8)
    }
}

// MARK: - Row Components
private struct RowWithSubtitle: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 14) {
            iconBox(icon)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))

                Text(subtitle)
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255)) // #4c669a
            }

            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }

    private func iconBox(_ icon: String) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color(red: 231/255, green: 235/255, blue: 243/255)) // #e7ebf3
            Image(systemName: icon)
                .font(.system(size: 18, weight: .regular))
                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
        }
        .frame(width: 48, height: 48)
    }
}

private struct SimpleRow: View {
    let icon: String
    let title: String

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color(red: 231/255, green: 235/255, blue: 243/255)) // #e7ebf3
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .regular))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
            }
            .frame(width: 40, height: 40)

            Text(title)
                .font(.system(size: 16, weight: .regular))
                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))

            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }
}


#Preview {
    NavigationStack {
        SettingsView()
    }
}
