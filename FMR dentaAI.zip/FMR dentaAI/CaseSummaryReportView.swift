import SwiftUI

struct CaseSummaryReportView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // MARK: - Top Bar
            HStack {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .frame(width: 44, height: 44, alignment: .leading)
                }
                .buttonStyle(.plain)
                
                Spacer()
                
                Text("Case Summary Report")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                
                Spacer()
                
                Color.clear.frame(width: 44, height: 44)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.white)
            
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 32) {
                    
                    // Clinical Diagnosis
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Clinical Diagnosis")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        
                        Grid(alignment: .leading, horizontalSpacing: 24, verticalSpacing: 16) {
                            GridRow {
                                DiagnosisItem(label: "Patient Name", value: "Raju")
                                DiagnosisItem(label: "Age", value: "20")
                            }
                            Divider()
                            GridRow {
                                DiagnosisItem(label: "Gender", value: "Male")
                                DiagnosisItem(label: "Medical History", value: "Non-smoker, no known allergies")
                            }
                            Divider()
                            GridRow {
                                DiagnosisItem(label: "Dental History", value: "Regular check-ups, minor fillings")
                                DiagnosisItem(label: "Chief Complaint", value: "Discomfort in lower right quadrant")
                            }
                            Divider()
                            GridRow {
                                DiagnosisItem(label: "Radiographic Findings", value: "No significant findings")
                                DiagnosisItem(label: "Clinical Findings", value: "Mild gingivitis, caries on #30")
                            }
                        }
                    }
                    
                    // Sequencing Logic
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Sequencing Logic")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        
                        VStack(alignment: .leading, spacing: 20) {
                            SequencePhaseItem(phase: "Phase 1", description: "Scaling and root planing, oral hygiene instructions")
                            SequencePhaseItem(phase: "Phase 2", description: "Restorative treatment for #30, periodontal maintenance")
                            SequencePhaseItem(phase: "Phase 3", description: "Review and follow-up")
                        }
                    }
                    
                    // Identified Risks
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Identified Risks")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        
                        RiskItem(title: "Periodontal Disease Progression", level: "Moderate")
                        RiskItem(title: "Caries Progression", level: "Low")
                    }
                    
                    // Final Recommendation
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Final Recommendation")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        
                        Text("Based on the clinical and radiographic findings, the recommended treatment plan for Ethan Carter includes scaling and root planing, restorative treatment for tooth #30, and a follow-up review. The patient should be educated on proper oral hygiene practices to prevent further progression of periodontal disease and caries.")
                            .font(.system(size: 16))
                            .foregroundColor(Color(red: 55/255, green: 65/255, blue: 81/255))
                            .lineSpacing(4)
                    }
                }
                .padding(20)
            }
        }
        .background(Color(red: 248/255, green: 249/255, blue: 252/255))
        .navigationBarHidden(true)
    }
}

private struct DiagnosisItem: View {
    let label: String
    let value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.system(size: 14)).foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
            Text(value).font(.system(size: 14, weight: .medium)).foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
        }
    }
}

private struct SequencePhaseItem: View {
    let phase: String
    let description: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(phase).font(.system(size: 14, weight: .medium)).foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
            Text(description).font(.system(size: 15)).foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
        }
    }
}

private struct RiskItem: View {
    let title: String
    let level: String
    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(red: 231/255, green: 235/255, blue: 243/255))
                    .frame(width: 44, height: 44)
                Image(systemName: "exclamationmark.triangle")
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 16, weight: .medium)).foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                Text(level).font(.system(size: 14)).foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
            }
        }
    }
}

#Preview {
    CaseSummaryReportView()
}
