import SwiftUI

struct CaseSubmissionReviewView: View {
    @Environment(\.dismiss) var dismiss
    @State private var showSuccessAlert = false
    @State private var navigateToSequence = false
    @ObservedObject private var repository = CaseRepository.shared
    
    var body: some View {
        VStack(spacing: 0) {
            // MARK: - Top Bar
            HStack {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .frame(width: 44, height: 44, alignment: .leading)
                }
                .buttonStyle(.plain)
                
                Text("Review Case")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.white)
            
            Divider()
                .overlay(Color(red: 231/255, green: 235/255, blue: 243/255))
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Review & Confirm")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                    
                    Text("Please review the information before submitting.")
                        .font(.system(size: 16, weight: .regular))
                        .foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
                    
                    VStack(alignment: .leading, spacing: 16) {
                        ReviewRow(title: "Patient Name", value: repository.draftPatientName.isEmpty ? "New Patient" : repository.draftPatientName)
                        ReviewRow(title: "Chief Complaint", value: repository.draftChiefComplaint.isEmpty ? "Evaluation" : repository.draftChiefComplaint)
                        ReviewRow(title: "PDI Class", value: "PDI Class I")
                        ReviewRow(title: "Analysis", value: "AI Evaluation Completed")
                    }
                    .padding(16)
                    .background(Color.white)
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(red: 207/255, green: 215/255, blue: 231/255), lineWidth: 1))
                }
                .padding(16)
            }
            
            Spacer()
            
            // MARK: - Navigation Button
            Button {
                submitCase()
            } label: {
                Text("Submit Case")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(RoundedRectangle(cornerRadius: 8, style: .continuous).fill(Color(red: 0/255, green: 122/255, blue: 255/255)))
            }
            .padding(16)
        }
        .background(Color(red: 248/255, green: 249/255, blue: 252/255))
        .navigationBarHidden(true)
        .fullScreenCover(isPresented: $navigateToSequence) {
            NavigationStack {
                TreatmentSequenceView()
            }
        }
        .overlay(
            Group {
                if showSuccessAlert {
                    ZStack {
                        Color.black.opacity(0.4).edgesIgnoringSafeArea(.all)
                        VStack(spacing: 16) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 50))
                                .foregroundColor(Color(red: 7/255, green: 136/255, blue: 59/255)) // Green
                            
                            Text("Success")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(Color(red: 7/255, green: 136/255, blue: 59/255)) // Green
                            
                            Text("Patient case has been created successfully!")
                                .multilineTextAlignment(.center)
                                .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                            
                            Button {
                                withAnimation {
                                    showSuccessAlert = false
                                }
                                // Slight delay to let alert close before navigating
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                    navigateToSequence = true
                                }
                            } label: {
                                Text("Continue")
                                    .fontWeight(.semibold)
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color(red: 7/255, green: 136/255, blue: 59/255))
                                    .cornerRadius(10)
                            }
                        }
                        .padding(24)
                        .background(Color.white)
                        .cornerRadius(20)
                        .padding(40)
                    }
                }
            }
        )
    }
    
    // Add logic to save case
    func submitCase() {
        CaseRepository.shared.addCase()
        showSuccessAlert = true
    }
}

private struct ReviewRow: View {
    let title: String
    let value: String
    var body: some View {
        HStack {
            Text(title).font(.system(size: 14, weight: .regular)).foregroundColor(Color(red: 76/255, green: 102/255, blue: 154/255))
            Spacer()
            Text(value).font(.system(size: 14, weight: .medium)).foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
        }
    }
}
