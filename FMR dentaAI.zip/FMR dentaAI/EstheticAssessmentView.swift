import SwiftUI

struct EstheticAssessmentView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // MARK: - Top Bar
            HStack {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                        .frame(width: 44, height: 44, alignment: .leading)
                }
                .buttonStyle(.plain)
                
                Spacer()
                
                Text("Esthetic Assessment")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(red: 13/255, green: 18/255, blue: 27/255))
                
                Spacer()
                
                Color.clear.frame(width: 44, height: 44)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.white)
            
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {
                    // MARK: - Assessment Hero Image
                    AsyncImage(url: URL(string: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?q=80&w=1000&auto=format&fit=crop")) { image in
                        image.resizable()
                            .scaledToFill()
                    } placeholder: {
                        Color(red: 243/255, green: 244/255, blue: 246/255)
                            .overlay(ProgressView())
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 380)
                    .clipped()
                    
                    VStack(alignment: .leading, spacing: 16) {
                        // MARK: - Results Title
                        Text("Results")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(Color(red: 17/255, green: 24/255, blue: 39/255))
                            .padding(.top, 24)
                        
                        // MARK: - Diagnostic Recommendation
                        Text("Diagnostic wax-up required to plan the final smile aesthetics.")
                            .font(.system(size: 16, weight: .regular))
                            .foregroundColor(Color(red: 55/255, green: 65/255, blue: 81/255))
                            .lineSpacing(4)
                    }
                    .padding(.horizontal, 16)
                }
            }
            
            Spacer()
            
            // MARK: - Next Button
            NavigationLink(destination: ProblemSummaryView()) {
                Text("Next")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color(red: 37/255, green: 99/255, blue: 235/255))
                    )
            }
            .buttonStyle(.plain)
            .padding(16)
        }
        .background(Color.white)
        .navigationBarHidden(true)
    }
}
